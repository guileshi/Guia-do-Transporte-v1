$(window).on('load', function(){
    $("#myModal").modal('show');
})


