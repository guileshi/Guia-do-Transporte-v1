// Iniciar contador de numeros
"use strict";
$('.contar').counterUp({
    time: 1000,
    delay: 20
});