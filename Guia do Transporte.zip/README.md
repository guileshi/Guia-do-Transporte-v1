<h1 align="center"> Guia do Transporte </h1>

<div align="center"> 🚧 <strong>UNDER CONSTRUCTION</strong> 🚧 </div>

<br>

<div align="center"> Remaking <a href="https://guiadotransporte.com.br"> Guia do Transporte <a/> website using <strong>HTML5, CSS3, JS, Bootstrap and JQuery</strong> </div>

<br>

![image](https://user-images.githubusercontent.com/83225183/148439884-54fe9019-ee81-46c9-b317-809287f95aca.png)

*some visual bugs, just ignore it*

✔️ **INDEX PAGE** <br>
✔️ **ORIGIN & DESTINY PAGE** <br>
✔️ **ABOUT US PAGE** <br>
✔️ **TERMS OF SERVICES PAGE** <br>
✔️ **CARRIERS PAGE** <br>
✔️ **CARRIERS DETAILS PAGE**
